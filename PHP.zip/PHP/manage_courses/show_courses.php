<?php
include 'course.php';
?>
<html>
    <head>
        <title>Show Courses</title>
        <meta charset="UTF-8">
         <link rel="stylesheet" type="text/css" href="course_style.css">
         <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
         <script src="courses.js"></script>
    </head>
    <body>
        <?php echo $courses ?>
    </body>
</html>
