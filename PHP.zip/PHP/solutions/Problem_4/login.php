<?php // login.php
  $db_hostname = 'localhost';
  $db_database = 'cs371spring2021';
  $db_username = 'root';
  $db_password = '';
?>
