<!DOCTYPE html>
<html>
    <head>
        <title>Hello World</title>
    </head>
    <body>
        <?php
        //this is a comment
        /* this is a multiline
         * comment
         */
        echo 'Hello World!';
        ?>
    </body>
</html>
