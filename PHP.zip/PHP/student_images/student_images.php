<?php
include 'students.php';
?>
<html>
    <head>
        <title>Show students</title>
        <meta charset="UTF-8">
         <link rel="stylesheet" type="text/css" href="style/style.css">
    </head>
    <body>
        <?php echo $students ?>
    </body>
</html>

