<!DOCTYPE html>
<html>
<body>
<?php

/* 
 Write a function that converts this array into a string, the words are separated by commas:
 * /
 */

$fruits_1=array('Apples','Bananas','Dates','Oranges');

?>

</body>
</html>