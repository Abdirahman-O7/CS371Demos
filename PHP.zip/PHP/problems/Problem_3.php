<!DOCTYPE html>
<html>
<body>
<?php


$date = date_create("2020-11-16"); //Monday, Nov 16, 2020


?>


</body>
</html>